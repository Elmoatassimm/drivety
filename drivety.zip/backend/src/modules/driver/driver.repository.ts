import { injectable, inject } from "tsyringe";
import { BaseRepository } from "../../core/base/BaseRepository";
import { IDriver } from "./interfaces/IDriverRepository";
import IDriverRepository from "./interfaces/IDriverRepository";
import PrismaService from "../../config/db";
import { NotFoundError } from "../../core/errors/AppError";

@injectable()
export class DriverRepository extends BaseRepository<IDriver> implements IDriverRepository {
  protected modelName = "driver";

  constructor(@inject("db") prismaService: PrismaService) {
    super(prismaService);
  }

  async findByUserId(userId: string): Promise<IDriver | null> {
    return this.prisma.driver.findUnique({
      where: { userId }
    });
  }

  async create(data: {
    userId: string;
    name: string;
    licenseNumber: string;
    licenseExpiry: Date;
    phoneNumber: string;
  }): Promise<IDriver> {
    return this.prisma.driver.create({
      data: {
        userId: data.userId,
        name: data.name,
        licenseNumber: data.licenseNumber,
        licenseExpiry: data.licenseExpiry,
        phoneNumber: data.phoneNumber,
        driverScore: 0 // Default score for new drivers
      }
    });
  }

  async updateDriverScore(id: string, score: number): Promise<IDriver> {
    const driver = await this.findById(id);
    if (!driver) {
      throw new NotFoundError("Driver");
    }

    return this.prisma.driver.update({
      where: { id },
      data: { driverScore: score }
    });
  }
}
