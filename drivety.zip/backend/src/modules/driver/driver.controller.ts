import { Request, Response, NextFunction } from "express";
import { inject, injectable } from "tsyringe";
import { BaseController } from "../../core/base/BaseController";
import { DriverService } from "./driver.service";
import ResponseUtils from "../../core/utils/response.utils";
import { IDriver } from "./interfaces/IDriverRepository";
import { RequestWithUser } from "../../types/types";
import { NotFoundError } from "../../core/errors/AppError";

@injectable()
export class DriverController extends BaseController<IDriver> {
  constructor(
    @inject("IDriverService") private driverService: DriverService,
    @inject("responseUtils") responseUtils: ResponseUtils
  ) {
    super(driverService, responseUtils);
  }

  async createDriver(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { userId, name, licenseNumber, licenseExpiry, phoneNumber } = req.body;
      
      const driver = await this.driverService.create({
        userId,
        name,
        licenseNumber,
        licenseExpiry: new Date(licenseExpiry),
        phoneNumber
      });
      
      this.responseUtils.sendSuccessResponse(res, driver, 201);
    } catch (error) {
      next(error);
    }
  }

  async getDriverByUserId(req: RequestWithUser, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = req.params.userId || req.user?.id;
      
      if (!userId) {
        throw new NotFoundError("User ID is required");
      }
      
      const driver = await this.driverService.findByUserId(userId);
      
      if (!driver) {
        throw new NotFoundError("Driver");
      }
      
      this.responseUtils.sendSuccessResponse(res, driver);
    } catch (error) {
      next(error);
    }
  }

  async updateDriverScore(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { id } = req.params;
      const { score } = req.body;
      
      const driver = await this.driverService.updateDriverScore(id, score);
      
      this.responseUtils.sendSuccessResponse(res, driver);
    } catch (error) {
      next(error);
    }
  }

  async getCurrentUserDriver(req: RequestWithUser, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user?.id) {
        throw new NotFoundError("User not authenticated");
      }
      
      const driver = await this.driverService.findByUserId(req.user.id);
      
      if (!driver) {
        throw new NotFoundError("Driver not found for current user");
      }
      
      this.responseUtils.sendSuccessResponse(res, driver);
    } catch (error) {
      next(error);
    }
  }
}
