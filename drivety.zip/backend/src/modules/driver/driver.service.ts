import { inject, injectable } from "tsyringe";
import { BaseService } from "../../core/base/BaseService";
import { IDriver } from "./interfaces/IDriverRepository";
import IDriverRepository from "./interfaces/IDriverRepository";
import IDriverService from "./interfaces/IDriverService";
import { DriverRepository } from "./driver.repository";
import { NotFoundError, ConflictError } from "../../core/errors/AppError";

@injectable()
export class DriverService extends BaseService<IDriver> implements IDriverService {
  protected entityName = "Driver";

  constructor(
    @inject("IDriverRepository") private driverRepository: IDriverRepository,
    @inject(DriverRepository) repository: DriverRepository
  ) {
    super(repository);
  }

  // We don't need to override findById as it's already implemented in BaseService

  async findByUserId(userId: string): Promise<IDriver | null> {
    return this.driverRepository.findByUserId(userId);
  }

  async create(data: {
    userId: string;
    name: string;
    licenseNumber: string;
    licenseExpiry: Date;
    phoneNumber: string;
  }): Promise<IDriver> {
    // Check if driver already exists for this user
    const existingDriver = await this.driverRepository.findByUserId(data.userId);
    if (existingDriver) {
      throw new ConflictError("Driver already exists for this user");
    }

    return this.driverRepository.create(data);
  }

  async update(id: string, data: Partial<Omit<IDriver, "id" | "userId" | "createdAt" | "updatedAt">>): Promise<IDriver> {
    const driver = await this.driverRepository.findById(id);
    if (!driver) {
      throw new NotFoundError("Driver");
    }

    return this.driverRepository.update(id, data);
  }

  async updateDriverScore(id: string, score: number): Promise<IDriver> {
    if (score < 0 || score > 100) {
      throw new Error("Driver score must be between 0 and 100");
    }

    return this.driverRepository.updateDriverScore(id, score);
  }
}
