import { inject, injectable } from "tsyringe";
import bcrypt from "bcryptjs";
import IAuthService from "./interfaces/IAuthService";
import IUserRepository from "../user/interfaces/IUserRepository";
import IRefreshTokenRepository from "./interfaces/IRefreshTokenRepository";
import JwtUtils from "../../core/utils/jwt.utils";
import { TAuthToken } from "../../types/types";
import {
  ConflictError,
  NotFoundError,
  InternalServerError,
  UnauthorizedError,
} from "../../core/errors/AppError";

@injectable()
export default class AuthService implements IAuthService {
  constructor(
    @inject("IUserRepository") private userRepository: IUserRepository,
    @inject("IRefreshTokenRepository") private refreshTokenRepository: IRefreshTokenRepository,
    @inject("jwt") private jwt: JwtUtils,
  ) {}

  async register(email: string, password: string, username: string): Promise<TAuthToken> {
    try {
      const existingUser = await this.userRepository.findByEmail(email);
      if (existingUser) throw new ConflictError("User already exists");

      const password_hash = await bcrypt.hash(password, 10);

      const user = await this.userRepository.createUser({
        email,
        password_hash,
        username,
      });

      const accessToken = this.jwt.generateAccessToken(
        user.id,
        user.email,
        user.username || 'user',
      );
      const refreshToken = this.jwt.generateRefreshToken(user.id, user.email);

      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 15);

      await this.refreshTokenRepository.create(
        user.id,
        refreshToken,
        expiresAt,
      );

      return { accessToken, refreshToken };
    } catch (error) {
      if (error instanceof ConflictError) throw error;
      throw new InternalServerError("Failed to register user");
    }
  }

  async login(email: string, password: string): Promise<TAuthToken> {
    try {
      const user = await this.userRepository.findByEmail(email);
      if (!user) throw new NotFoundError("User");

      const isPasswordValid = await bcrypt.compare(
        password,
        user.password_hash || user.password,
      );
      if (!isPasswordValid) throw new UnauthorizedError("Invalid credentials");

      const accessToken = this.jwt.generateAccessToken(
        user.id,
        user.email,
        user.username || 'user',
      );
      const refreshToken = this.jwt.generateRefreshToken(user.id, user.email);
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 15);

      await this.refreshTokenRepository.create(
        user.id,
        refreshToken,
        expiresAt,
      );

      return { accessToken, refreshToken };
    } catch (error) {
      if (
        error instanceof NotFoundError ||
        error instanceof UnauthorizedError
      ) {
        throw error;
      }
      throw new InternalServerError("Failed to login");
    }
  }

  async refreshTokens(refreshToken: string): Promise<TAuthToken> {
    try {
      const userId = this.jwt.getUserFromRefreshToken(refreshToken);

      const storedRefreshToken =
        await this.refreshTokenRepository.findByUserId(userId);

      if (
        !storedRefreshToken ||
        storedRefreshToken.token !== refreshToken ||
        storedRefreshToken.expiresAt < new Date()
      ) {
        throw new UnauthorizedError("Invalid refresh token");
      }

      const user = await this.userRepository.findById(userId);
      if (!user) throw new NotFoundError("User");

      const newAccessToken = this.jwt.generateAccessToken(
        user.id,
        user.email,
        user.username || 'user',
      );
      const newRefreshToken = this.jwt.generateRefreshToken(
        user.id,
        user.email,
      );

      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 15);

      await this.refreshTokenRepository.updateByUserId(
        user.id,
        newRefreshToken,
        expiresAt,
      );

      return { accessToken: newAccessToken, refreshToken: newRefreshToken };
    } catch (error) {
      if (
        error instanceof UnauthorizedError ||
        error instanceof NotFoundError
      ) {
        throw error;
      }
      throw new InternalServerError("Failed to refresh tokens");
    }
  }

  async logout(token: string): Promise<void> {
    try {
      const userId = this.jwt.getUserIdFromToken(token);
      await this.refreshTokenRepository.deleteByUserId(userId);
    } catch (error) {
      if (error instanceof UnauthorizedError) {
        throw error;
      }
      throw new InternalServerError("Failed to logout");
    }
  }
}
