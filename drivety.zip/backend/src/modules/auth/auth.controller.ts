import { Request, Response, NextFunction } from "express";
import { injectable, inject } from "tsyringe";
import IAuthService from "./interfaces/IAuthService";
import ResponseUtils from "../../core/utils/response.utils";
import { RequestWithUser } from "../../types/types";
import { UnauthorizedError } from "../../core/errors/AppError";

@injectable()
export default class AuthController {
  constructor(
    @inject("IAuthService") private authService: IAuthService,
    @inject("responseUtils") private responseUtils: ResponseUtils
  ) {}

  async register(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { email, password, username } = req.body;
      const tokens = await this.authService.register(email, password, username);
      this.responseUtils.sendSuccessResponse(res, tokens, 201);
    } catch (error) {
      next(error);
    }
  }

  async login(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { email, password } = req.body;
      const tokens = await this.authService.login(email, password);
      this.responseUtils.sendSuccessResponse(res, tokens);
    } catch (error) {
      next(error);
    }
  }

  async refreshToken(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const refreshToken = req.header("x-refresh-token");
      
      if (!refreshToken) {
        throw new UnauthorizedError("Refresh token is required");
      }
      
      const tokens = await this.authService.refreshTokens(refreshToken);
      this.responseUtils.sendSuccessResponse(res, tokens);
    } catch (error) {
      next(error);
    }
  }

  async logout(req: RequestWithUser, res: Response, next: NextFunction): Promise<void> {
    try {
      const token = req.header("Authorization")?.replace("Bearer ", "");
      
      if (!token) {
        throw new UnauthorizedError("Authentication token is required");
      }
      
      await this.authService.logout(token);
      this.responseUtils.sendSuccessNoDataResponse(res, "Logged out successfully");
    } catch (error) {
      next(error);
    }
  }
}
