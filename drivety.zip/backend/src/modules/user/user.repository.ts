import { injectable, inject } from "tsyringe";
import { BaseRepository } from "../../core/base/BaseRepository";
import { IUser } from "./interfaces/IUserRepository";
import PrismaService from "../../config/db";
import IUserRepository from "./interfaces/IUserRepository";

@injectable()
export class UserRepository extends BaseRepository<IUser> implements IUserRepository {
  protected modelName = "user";

  constructor(@inject("db") prismaService: PrismaService) {
    super(prismaService);
  }

  async findByEmail(email: string): Promise<IUser | null> {
    return this.prisma.user.findUnique({ where: { email } });
  }

  async createUser(data: { email: string; password_hash: string; username: string }): Promise<IUser> {
    const user = await this.prisma.user.create({
      data: {
        email: data.email,
        password: data.password_hash,
        role: "USER"
      }
    });

    // Add the username property to match the interface
    return {
      ...user,
      username: data.username
    };
  }

  async updatePassword(id: string, password: string): Promise<IUser> {
    return this.prisma.user.update({
      where: { id },
      data: { password }
    });
  }

  async getProfile(id: string): Promise<Partial<IUser> | null> {
    return this.prisma.user.findUnique({
      where: { id },
      select: { id: true, email: true, role: true }
    });
  }
}
